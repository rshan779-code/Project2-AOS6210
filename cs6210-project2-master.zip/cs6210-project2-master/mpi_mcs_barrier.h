#ifndef PROJECT2_MPI_MCS_BARRIER_H
#define PROJECT2_MPI_MCS_BARRIER_H

#include "mpi.h"

void MPI_mcs_barrier(MPI_Comm comm, int tag);

#endif //PROJECT2_MPI_MCS_BARRIER_H
