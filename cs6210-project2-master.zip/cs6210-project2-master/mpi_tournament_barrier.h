#ifndef PROJECT2_MPI_TOURNAMENT_BARRIER_H
#define PROJECT2_MPI_TOURNAMENT_BARRIER_H

#include "mpi.h"

void MPI_tournament_barrier(MPI_Comm comm, int tag);

#endif //PROJECT2_MPI_TOURNAMENT_BARRIER_H
