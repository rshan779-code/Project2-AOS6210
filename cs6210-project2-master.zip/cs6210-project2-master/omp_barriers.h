#ifndef PROJECT2_OMP_BARRIERS_H
#define PROJECT2_OMP_BARRIERS_H

#include "omp_centralized_barrier.h"
#include "omp_tree_barrier.h"
#include "omp_tournament_barrier.h"
#include "omp_dissemination_barrier.h"
#include "omp_mcs_barrier.h"

#endif //PROJECT2_OMP_BARRIERS_H
